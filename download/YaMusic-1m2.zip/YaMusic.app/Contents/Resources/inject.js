function onWindowLoad() {
    console.log("onWindowLoad");
    
    document.body.style.background = "#ffffff"
    
    window.webkit.messageHandlers.DOMeventPageLoad.postMessage("Hello, world!");
}

var eventHandlers = {}
eventHandlers[externalAPI.EVENT_READY] = function() { window.webkit.messageHandlers.eventReady.postMessage("We are ready!"); } // готовность данного интерфейса

// eventHandlers[externalAPI.EVENT_PROGRESS] = function() { window.webkit.messageHandlers.eventProgress.postMessage("eventProgress"); } // изменение временных метрик трека
eventHandlers[externalAPI.EVENT_VOLUME] = function() { window.webkit.messageHandlers.eventVolume.postMessage("We are ready!"); } // изменение громкости

eventHandlers[externalAPI.EVENT_TRACKS_LIST] = function() {
    window.webkit.messageHandlers.eventTracksList.postMessage("We are ready!");
    console.log("EVENT_TRACKS_LIST");
} // изменения списка треков

eventHandlers[externalAPI.EVENT_SOURCE_INFO] = function() { window.webkit.messageHandlers.eventSourceInfo.postMessage("We are ready!"); } // смена источника воспроизведения

eventHandlers[externalAPI.EVENT_CONTROLS] = function() {
    var controls = externalAPI.getControls();
    if(controls){
        window.webkit.messageHandlers.eventControls.postMessage(JSON.stringify(controls));
    }
} // изменение состояния элементов управления (в т.ч. смены состояния шаффла и повтора треков)

eventHandlers[externalAPI.EVENT_ADVERT] = function() { window.webkit.messageHandlers.eventAdvert.postMessage("We are ready!"); } // воспроизведение рекламы

eventHandlers[externalAPI.EVENT_TRACK] = function() { window.webkit.messageHandlers.eventTrack.postMessage(JSON.stringify(externalAPI.getCurrentTrack()));
} // смена трека

eventHandlers[externalAPI.EVENT_STATE] = function() {
    var state = { currentTrack: externalAPI.getCurrentTrack() };
    window.webkit.messageHandlers.eventState.postMessage(JSON.stringify(state));
} // изменение состояния плеера


window.onload = onWindowLoad;

Object.keys(eventHandlers).forEach(function (key) {
    externalAPI.on(key, eventHandlers[key]);
});
